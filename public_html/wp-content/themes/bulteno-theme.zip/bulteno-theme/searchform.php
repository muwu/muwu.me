						<div class="search">
							<!-- BEGIN .searchform -->
							<form method="get" action="<?php echo home_url(); ?>" name="searchform" >
								<input type="text" placeholder="<?php printf ( __( 'search here' , THEME_NAME ));?>" class="search" name="s" id="s" />
							<!-- END .searchform -->
							</form>
						</div>