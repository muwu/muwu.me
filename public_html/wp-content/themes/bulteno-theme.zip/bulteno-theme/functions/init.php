<?php
	
	get_template_part(THEME_FUNCTIONS.'filters');
	get_template_part(THEME_FUNCTIONS.'register');
	get_template_part(THEME_FUNCTIONS.'thumbs');
	get_template_part(THEME_FUNCTIONS.'nav');
	
	get_template_part(THEME_FUNCTIONS.'other');
	get_template_part(THEME_FUNCTIONS.'ajax');
	get_template_part(THEME_FUNCTIONS.THEME_NAME,'menu');
	get_template_part(THEME_FUNCTIONS.'jquery-css-include');
?>