<aside class="right-sidebar">

<?php if ( dynamic_sidebar('right_sidebar') ) : else : endif; ?>

</aside>