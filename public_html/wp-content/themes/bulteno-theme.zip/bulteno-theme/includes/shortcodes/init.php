<?php
	get_template_part(THEME_SHORTCODES.'buttons');
	get_template_part(THEME_SHORTCODES.'gallery-box');
	get_template_part(THEME_SHORTCODES.'lists');
	get_template_part(THEME_SHORTCODES.'qoutes');
	get_template_part(THEME_SHORTCODES.'spacers');
	get_template_part(THEME_SHORTCODES.'caption');
	get_template_part(THEME_SHORTCODES.'googlemap');
	get_template_part(THEME_SHORTCODES.'paragraph');
	get_template_part(THEME_SHORTCODES.'video');
	get_template_part(THEME_SHORTCODES.'social');

?>