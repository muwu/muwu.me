<?php
	get_template_part(THEME_WIDGETS.'widget','ad300x250');
	get_template_part(THEME_WIDGETS.'widget','ad300x600');
	get_template_part(THEME_WIDGETS.'widget-'.THEME_NAME,'gallery');
	get_template_part(THEME_WIDGETS.'widget-'.THEME_NAME,'latest-posts');
	get_template_part(THEME_WIDGETS.'widget-'.THEME_NAME,'category-posts');
	get_template_part(THEME_WIDGETS.'widget-'.THEME_NAME,'popular-comments');
	get_template_part(THEME_WIDGETS.'widget-'.THEME_NAME,'aweber');

?>