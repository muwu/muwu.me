<header class="page-header">

	<h1 class="page-title"><?php _e( 'Nothing Found', 'micsokoli' ); ?></h1>
	
</header> <!-- page-header -->

<div class="page-content">
	
	<p><?php _e( 'Sorry, but nothing matched', 'micsokoli') ?></p>

</div> <!-- page-content -->